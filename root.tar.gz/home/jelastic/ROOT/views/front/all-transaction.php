<?php include('header.php');?>

<section class="dash-inner-sec">
    <div class="container">
        <div class="row">
             <div class="col-lg-10 offset-lg-1 col-md-12">
                 <div class="dashboard-box">
                     <div class="create-wallet-block">
                            <h3 class="main-heading wow slideInLeft">Notifications</h3>
                            <h4 class="green-heading wow slideInRight">All Notifications</h4> 
                             <div class="row">
                               <div class="col-md-12">
                                 <div class="all-notification-block">
                                   <div class="notification-inner">
                                     <div class="media">
                                        <img class="align-self-center mr-3" src="assets/images/other/sent-rwn-01.png" alt="Generic placeholder image">
                                        <div class="media-body">
                                          <h5 class="mt-0">Center-aligned media</h5>
                                          <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio,</p>
                                          
                                        </div>
                                      </div>
                                   </div>
                                     <div class="notification-inner">
                                     <div class="media">
                                        <img class="align-self-center mr-3" src="assets/images/other/sent-rwn-01.png" alt="Generic placeholder image">
                                        <div class="media-body">
                                          <h5 class="mt-0">Center-aligned media</h5>
                                          <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio,</p>
                                          
                                        </div>
                                      </div>
                                   </div>
                                     <div class="notification-inner">
                                     <div class="media">
                                        <img class="align-self-center mr-3" src="assets/images/other/sent-rwn-01.png" alt="Generic placeholder image">
                                        <div class="media-body">
                                          <h5 class="mt-0">Center-aligned media</h5>
                                          <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio,</p>
                                          
                                        </div>
                                      </div>
                                   </div>
                                 </div>
                               </div>
                             </div>
                        </div>
                 </div>
             </div>
        </div>
    </div>
</section>

<?php include('footer.php');?>