var express = require('express');
var path = require('path');
var http = require('http');
var mongoose = require('mongoose');
var config = require('./config/database');
var bodyParser = require('body-parser');
var session = require('express-session');
var expressValidator = require('express-validator');
var fileUpload = require('express-fileupload');

// var passport = require('passport');

var fs = require('fs-extra');   
var path = require('path');

//Connect to db
mongoose.connect(config.database);
var db = mongoose.connection;

db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    console.log('Connected to MongoDB');
});

// Init app
var app = express();
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: false }));
// Set global errors variable
app.locals.errors = null;


// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Set public folder
app.use(express.static(path.join(__dirname, 'public')));
app.use(fileUpload());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(expressValidator());



var flash = require('express-flash')
var cookieParser = require('cookie-parser');
var session = require('express-session');
 
app.use(cookieParser('keyboard cat'))
app.use(session({ 
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    //cookie: { maxAge: 60000 }
}))
app.use(flash())

// Passport Config
// require('./config/passport')(passport);
//  Passport Middleware
// app.use(passport.initialize());
// app.use(passport.session());


app.get('*', function(req,res,next) {
   res.locals.cart  = req.session.cart;
   res.locals.user  = req.user || null;
   next();
});


// get routes 
var front = require('./routes/front.js');
var admin = require('./routes/admin.js');

// Use rout 
app.use('/', front);
app.use('/admin', admin);


// Start the server
var port = 2300;
app.listen(port, function () {
    console.log('Server started on port ' + port);
});
   
