module.exports = {
    database: 'mongodb://Rowan_user:Rowan_user123@node16848-env-3320774.cloudjiffy.net:27017/Rowan_energy'
}


