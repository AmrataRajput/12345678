var mongoose = require('mongoose');

// Admin Schema
var AdminSchema = mongoose.Schema({
   
    name: {
        type: String,
        
    },
     designation: {
        type: String,
        
    },
    email: {
        type: String,
        
    },
    mobile: {
        type: String,
       
    },
    password: {
        type: String,
       
    },
    address: {
        type: String,
       
    },
    image: {
        type: String,
         default : null,
       
    },
    status: {
        type: String,
        enum: ['active','deactive'],
        default : "active",
       
    },
    deleted: {
        type: String,
        enum: ['0','1'],
        default : "1",
     },
     created_at: {
        type: String,
      }
    
   
});

var Admin = module.exports = mongoose.model('Admin', AdminSchema);

